void intro(hd44780_I2Cexp lcd){
  String projectName = PROJECT_NAME; //Variable definition. Under the PROJECT_NAME we have "LCDText"
  String version = VERSION;
  
	lcd.clear(); 
	lcd.setCursor(0, 0);
	lcd.print("TMEeducation.com");
  
	lcd.setCursor(0, 1);
  for(int i = 0; i < (16 - projectName.length()) / 2; i++){
    lcd.print(" ");
  }

  //Here we print variable. Look higher at its definition. We can also print integer/char/... variables.
	lcd.print(projectName);
  
	delay(2500);
  
	lcd.setCursor(0, 1);
  lcd.print("                ");
  
  lcd.setCursor(0, 1);
  for(int i = 0; i < (16 - version.length()) / 2; i++){
    lcd.print(" ");
  }
	lcd.print(VERSION);

	delay(2500);

  //Look here. With this command you can clean the screen
  lcd.clear();
  delay(100);
}
