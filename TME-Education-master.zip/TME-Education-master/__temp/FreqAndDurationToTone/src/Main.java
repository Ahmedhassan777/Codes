import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        String song = "0,166;740,166;740,166;740,166;987,999;1480,999;1319,166;1245,166;1109,166;1976,999;1480,499;1319,166;1245,166;1109,166;1976,999;1480,499;1319,166;1245,166;1319,166;1109,999;740,166;740,166;740,166;987,999;1480,999;1319,166;1245,166;1109,166;1976,999;1480,499;1319,166;1245,166;1109,166;1976,999;1480,499;1319,166;1245,166;1319,166;1109,666;";
        String[] tones = song.split(";");

        ArrayList<String[]> freqAndDuration = new ArrayList<>(tones.length);

        for(String s : tones){
            String[] temp = {s.split(",")[0], s.split(",")[1]};
            freqAndDuration.add(temp);
        }

//        for(String[] sa : freqAndDuration){
//            System.out.print(sa[0] + "," + sa[1] + ";");
//        }

        for(String[] sa : freqAndDuration){
            System.out.println("play(" + sa[0] + ", " + sa[1] + ");");
            System.out.println("delay(" + sa[1] + ");");
        }
    }
}
